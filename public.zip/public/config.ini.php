<?php

/**
 * Database Constants - these constants refer to
 * the database configuration settings.
 */

define('DB_SERVER', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', 'betweenlifestyle123456');
define('DB_DATABASE', 'senshare');
?>
